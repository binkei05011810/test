const showQuestion = async ({ params, request, response, state }) => {
    
};

const showQuestions = async ({ params, request, response, state }) => {
    
};

const postQuestion = async ({ params, request, response, state }) => {
    
};

export { showQuestion, showQuestions , postQuestion};