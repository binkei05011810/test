const showTopic = async ({ params, request, response, state }) => {
    
};

const deleteTopic = async ({ params, request, response, state }) => {
    
};

const postTopic = async ({ params, request, response, state }) => {
    
};

const showTopics = async ({ params, request, response, state }) => {
    
};



export { showTopic, deleteTopic, postTopic , showTopics};